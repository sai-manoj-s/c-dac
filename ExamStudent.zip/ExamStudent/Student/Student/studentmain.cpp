#include <iostream>
#include <string>
using namespace std;

int choice;
double avg, hmarks;
double arrayScore[2];

// Student class

class Student {
	int id;
	string name;
	long phone;

	double score1, score2, score3, score4;
	int arrayScore[3];

public:

	int getId() { return id; }
	string  getName() { return name; }
	long getPhone() { return phone; }
	double getScore1() { return score1; }
	double getScore2() { return score2; }
	double getScore3() { return score3; }
	double getScore4() { return score4; }



	void setId(int id)
	{
		this->id = id;
	}

	void setName(string name)
	{
		this->name = name;
	}

	void setPhone(long phone)
	{
		this->phone = phone;
	}

	void setScore1(double score1)
	{
		this->score1 = score1;
	}

	void setScore2(double score2)
	{
		this->score2 = score2;
	}
	void setScore3(double score3)
	{
		this->score3 = score3;
	}
	void setScore4(double score4)
	{
		this->score4 = score4;
	}



};


class Studentdatabase {

public:
	void insert(Student st[])
	{
		string name; int i; long phone; int id;
		double score1, score2, score3, score4;

		cout << "Enter students details *****" << endl;
		for (i = 0; i < 3; i++)
		{

			cout << "Enter id : ";
			cin >> id;
			cout << "Enter name : ";
			cin >> name;
			cout << "Enter phone : ";
			cin >> phone;
			cout << "Enter Score 1 : ";
			cin >> score1;
			cout << "Enter Score 2 : ";
			cin >> score2;
			cout << "Enter Score 3 : ";
			cin >> score3;
			cout << "Enter Score 4 : ";
			cin >> score4;
			st[i].setId(id);
			st[i].setName(name);
			st[i].setPhone(phone);
			st[i].setScore1(score1);
			st[i].setScore2(score2);
			st[i].setScore3(score3);
			st[i].setScore4(score4);
		}


	}

	void update(Student st[])
	{
		string name; int i; long phone;
		int id, updateid;
		double score1, score2, score3, score4;
		cout << "Enter id for record to be updated are *****" << endl;
		cin >> updateid;
		for (i = 0; i < 3; i++)
		{
			if (st[i].getId() == updateid)
			{

				cout << "Enter name : ";
				cin >> name;
				cout << "Enter phone : ";
				cin >> phone;
				cout << "Enter Score 1 : ";
				cin >> score1;
				cout << "Enter Score 2 : ";
				cin >> score2;
				cout << "Enter Score 3 : ";
				cin >> score3;
				cout << "Enter Score 4 : ";
				cin >> score4;
				st[i].setName(name);
				st[i].setPhone(phone);
				st[i].setPhone(phone);
				st[i].setScore1(score1);
				st[i].setScore2(score2);
				st[i].setScore3(score3);
				st[i].setScore4(score4);
			}

		}


	}

	void display(Student st[])
	{
		int i;

		cout << "The student details are *****" << endl;

		for (i = 0; i < 3; i++)
		{
			if (st[i].getId() != 0)
			{

				double	avg = (st[i].getScore1() + st[i].getScore2() + st[i].getScore3() + st[i].getScore4()) / 4;
				cout << "Student :\t" << st[i].getName() << "\t" << st[i].getPhone() << "\t Score 1:" << st[i].getScore1()
					<< "\t Score 2:" << st[i].getScore2() << "\t Score 3:" << st[i].getScore3() << "\t Score 4:" << st[i].getScore4()
					<< "\t Average :" << avg << endl;


			}

		}


	}

	void deleteStudent(Student st[])
	{
		int deleteid, i;

		cout << "Enter id for record to be deleted are *****" << endl;
		cin >> deleteid;
		for (i = 0; i < 3; i++)
		{
			if (st[i].getId() == deleteid)
			{
				st[i].setId(0);
				st[i].setName("");
				st[i].setPhone(0);
			}

		}


	}





};

void menu()
{
	cout << "**************** Student managment system ************** \n";
	cout << "**************** Press 1 for insert ************** \n";
	cout << "**************** Press 2 for update ************** \n";
	cout << "**************** Press 3 for delete ************** \n";
	cout << "**************** Press 4 for display ************** \n";
	cout << "**************** Ps : Any other choice for exit ************** \n";
}

bool processMenu(Studentdatabase stb, Student st[], int choice)
{
	switch (choice)
	{
	case 1:
		stb.insert(st);
		break;
	case 2:
		stb.update(st);
		break;
	case 3:
		stb.deleteStudent(st);
		break;
	case 4:
		stb.display(st);
		break;
	default:

		exit(1);
	}

	return true;
}

int main()
{
	// Creating student object array
	Student st[3];

	// Creating student database class
	Studentdatabase stb;
	bool processT = true;
	do {

		menu();
		cout << "Please enter choice" << endl;
		cin >> choice;
		bool processT = processMenu(stb, st, choice);

	} while (processT);

	system("pause");
	return 0;
}