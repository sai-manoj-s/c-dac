#include<iostream>
#include<string>
using namespace std;
class Patient
{
	int id,age;
	string name,address,gender;
	public:
		Patient(){
		}
	Patient(int id,int age,string name,string address,string gender):id(id),age(age),name(name),address(address),gender(gender)
	{
	}
	void SetId(int id)
	{
		this->id=id;
	}
	int getId()
	{
		return id;
	}
	void SetAge(int age)
	{
		this->age=age;
	}
	int getAge()
	{
		return age;
	}
	
	void SetName(string name)
	{
		this->name=name;
	}
	string getName()
	{
		return name;
	}
	void SetAddress(string address)
	{
		this->address=address;
	}
	string getAddress()
	{
		return address;
	}
	void SetGender(string gender)
	{
		this->gender=gender;
	}
};
