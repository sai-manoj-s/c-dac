#include"Patient.h"
#define count 10
class PatientDatabase
{
	private:
		Patient patients[count];
		
	public:
		PatientDatabase()
		{
		}
		void AddNewPatient(Patient obj);
		void RemovePatient(int id);
		void UpdatePatient(Patient obj);
		Patient FinfPatient(int id);		
};
