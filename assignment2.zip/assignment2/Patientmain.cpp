#include"CommonFunction.h"
#include"PatientDatabase.h"
PatientDatabase pnt;
string createmenu()
{
	string menu = "---------------------Patient Management software-----\n";
	       menu +="To Add New Patient----------------------Press 1-------\n";
	       menu +="To Update Patient Info------------------press 2-------\n";
	       menu +="To Delete Patient-----------------------press 3 ------\n";
	       menu +="To Find Patient-------------------------press 4-------\n";
	    return menu;
}

void AddPatientFeature()
{
	int id=getNumber("Enter the patient ID");
	int age=getNumber("Enter the age");
	string name=getString("Enter the name of patient");
	string address=getString("Enter the address");
	string gender=getString("Enter the gender");
	Patient obj(id,age,name,address,gender);
	pnt.AddNewPatient(obj);
}
void UpdatePatientFeature()
{
	int id=getNumber("Enter the patient ID to update");
	int age=getNumber("Enter the age to update");
	string name=getString("Enter the name of patient to update");
	string address=getString("Enter the address to update");
	string gender=getString("Enter the gender to update");
	Patient obj(id,age,name,address,gender);
	pnt.UpdatePatient(obj);
}
 void FindingPatientFeature()
 {
 	
 		int id=getNumber("Enter the patient ID to find");
	   pnt.FinfPatient(id);
 }
 void DletingPatientFeature()
 {
 		int id=getNumber("Enter the patient ID to Delete");
 	pnt.RemovePatient(id);
 }

bool processMenu(int choice)
{
	switch(choice)
	{
	
		
		case 1:
			  AddPatientFeature();
			  throw "can not add new patient";
			  return true;
		
		case 2:
			 UpdatePatientFeature();
			 return true;
		case 3:
			  FindingPatientFeature();
			  throw "Not be able to find patient";
			  return true;
		case 4:
				DletingPatientFeature();
				return true;
		default:
				return false;	
			
			
	}
}

int main()
{
	string menu = createmenu();
		int choice = getNumber(menu);
		try
		{
		
		    processMenu( choice);
	    }
	    catch(const char* msg)
	    {
	       	cout<<msg<<endl;
		}
		return 0;
		
}

