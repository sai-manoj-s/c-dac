#pragma once
#include<iostream>
#include<string>
using namespace std;
void print(string msg)
{
	cout<<msg<<endl;
}
 int getNumber(string msg)
 {
 	print(msg);
 	int answer=0;
 	cin>>answer;
 	return answer;
 }
 string getString(string msg)
 {
 	print(msg);
 	string answer;
 	cin>>answer;
 	return answer;
 }
