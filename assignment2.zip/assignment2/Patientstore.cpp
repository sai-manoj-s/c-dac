/*  create a class called patient that store the details of the patient from user  */
#include<fstream>
#include<iostream>
#include<string>
using namespace std;
class Patient
{
	int patientId,phoneNo;
	string name,address;
	public:
	Patient():patientId(0),phoneNo(0),name(" "),address(" "){
	}
	void Setdata(int,int,string,string);
	void showdata();
	void storePatient();
	
};
void Patient::Setdata(int patientId,int phoneNo,string name,string address )
{
	this->patientId=patientId;
	this->phoneNo=phoneNo;
	this->name=name;
	this->address=address;
}
void Patient::showdata()
{
	cout<<"patientId: "<<patientId<<"\n";
	cout<<"phoneNo: "<<phoneNo<<"\n";
	cout<<"name :"<<name<<"\n";
	cout<<"address :"<<address<<"\n";
}
void Patient::storePatient()
{
	ofstream obj1;
	obj1.open("PatientData.dat",ios::app);
	obj1.write((char*)this,sizeof(*this));
	obj1.close();
}

int main()
{
	Patient obj;
	int id,phoneno;
	string name,address;
	cout<<"Enter the value of id:";
	cin>>id;	
	cout<<"Enter the value of phoneno:";
	cin>>phoneno;	
	cout<<"Enter the value of name:";
	cin>>name;	
	cout<<"Enter the value of address:";
	cin>>address;
	obj.Setdata(id,phoneno,name,address);
	obj.showdata();	
	obj.storePatient();
	return 0;
}
