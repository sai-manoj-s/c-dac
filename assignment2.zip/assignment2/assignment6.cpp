
#include<iostream>
using namespace std;
class Myclass
{
	friend class MyAnotherClass;
	private:
		int secret=10;
	public:
	Myclass()
	{
	}
	void  show()
	{
		cout<<"secret:"<<secret<<"\n";
	} 
	friend  void display();
	 
};
class MyAnotherClass
{
	public:
		void showsecret(Myclass mc)
		{
			mc.secret++;
			cout<<"mc.secret"<<mc.secret;
		}
};
void display()
{
	 Myclass obj;
	 obj.show();

}
int main()
{
	display();
	MyAnotherClass mac;
	Myclass mc;
	mac.showsecret(mc);
	return 0;
}


