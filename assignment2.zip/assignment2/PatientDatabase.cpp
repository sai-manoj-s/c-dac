#include"PatientDatabase.h"


void PatientDatabase::AddNewPatient(Patient obj)
{ 
	for(int i=0;i<count;i++)
	{
		if(patients[i].getId()== 0)
		{
			patients[i]=obj;
			return;
		}
		else
		return;
	}
	
}

void PatientDatabase::RemovePatient(int id)
{
	for(int i=0;i<count;i++)
	{
	
		if(patients[i].getId()==id)
		{
			patients[i].SetId(0);
			patients[i].SetAge(0);
			patients[i].SetName(" ");
			patients[i].SetAddress(" ");
			patients[i].SetGender(" ");
			return;
		}
	}	
}

void PatientDatabase::UpdatePatient(Patient obj)
{
		for(int i=0;i<count;i++)
		{
		
			if(patients[i].getId()==obj.getId())
			{
				patients[i]=obj;
				return;
			}
    	}	
}
Patient PatientDatabase::FinfPatient(int id)
{
	for(int i=0;i<count;i++)
	{
		if(	patients[i].getId()==id)
		{
			return patients[i];
		}
		else
		{
		
		cout<<"cant find";
	}
		
	}
}
