//assignment 1
//comparing two numbers without comarision or arithmatic operator
#include<iostream>
using namespace std;

void compare(int first,int second){
	if(first^second){
		cout<<"numbers entered are not Same";
	}
	else{
		cout<<"number entered are same";
	}
}

int input(string msg){
	int num;
	cout<< msg<<endl;
	cin>>num;
	return num;
	
}

int main(){
	int first=input("Enter the first number");
	int second=input("Enter the first number");
	
	compare(first,second);
}
