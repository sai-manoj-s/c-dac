#pragma once
#include <iostream>
#include <string>

using namespace std;

class Employee
{
private:
	string name;
	int id;
	string adress;

public:
	Employee() 
	{
		this->name = "";
		this->id = 0;
		this->adress = "";
	};

	Employee(string name,int id,string adress) {
		this->name = name;
		this->id = id;
		this->adress = adress;
	};

	string Getname() { return name; }
	int Getid() { return id; }
	string Getadress() { return adress; }

	void Setname(string name) {this->name = name;}
	void Setid(int id) { this->id = id; }
	void Setadress(string adress) { this->adress = adress; }
	void ResetAccount ()
	{
		this->name = "";
		this->id = 0;
		this->adress = "";
	}
};
