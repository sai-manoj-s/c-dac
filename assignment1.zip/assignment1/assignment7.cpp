//assignment 7
//ternary operator

#include<iostream>
using namespace std;

int main(){
	int num;
	cout << "Enter a number to check : \n";
	cin >>num;
	num>0?cout <<" positive number":cout<< "Negative number";
}
