//assignment4
//calculate simple intrest

#include<iostream>
using namespace std;

void calculateIntrest( int principle,	double rate,	int time){
	int amount;
	amount=(principle*rate*time)/100;
	cout<< "your simple intrest is : " <<amount;
	
}


void input(){
	 int principle;
	double rate;
	int time;
	cout <<"enter your principle amount :\n";
	cin >>principle;
	cout <<"enter rate of intrest :\n";
	cin >>rate;
	cout <<"enter loan duration :\n";
	cin >>time;
	calculateIntrest(principle,rate,time); 
}

int main(){
	input();
}
