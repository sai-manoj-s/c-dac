//assignment 9
//menu driven C++ program with following option
//a. Accept elements of an array
//b. Display elements of an array 

#include<iostream>
using namespace std;


	int size;
int* takeArrayElements(){
	
		cout<< "Enter the size of array :\n";
		cin >> size;
		int* array= new int[size];
		
		for(int i=0; i<size; i++){
			cout<< "Enter the array element :\n";
		cin >> array[i];
		}
		return array;
	}
	
void displayArray(int* ar){
	cout <<"  Array elements are :\n";
	for(int i=0; i<size; i++){
	cout<<ar[i]<<", ";	
	}
	cout<<endl;
}
int menu(){
	int option;
	cout<<"To enter array elements-------->press 1\nTo display array elements---------->press 2\n   **press any other number to exit\n";
	cin >>option;
	return option;
}
int* ar;
 processmenu(int option){
 	switch(option){
 		case 1:
 			ar=takeArrayElements();
 			break;
 		case 2:
 			displayArray(ar);
 			break;			
	 }
 }

int main(){
	int op;
	do{
	op=menu();	
	processmenu(op);
	}while(op<3&&op>0);
	
//	
//	
}
