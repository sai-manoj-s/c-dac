#include "EmployeeManager.h"



EmployeeManager::EmployeeManager()
{
}

void EmployeeManager::AddAccount(Employee emp)
{
	for (int i = 0; i < 20; i++)
	{
		if (e[i].Getname() == "")
		{
			e[i] = emp;
			cout << "Account Created \n\n";
			i = 0;
			return;
		}
	}
	cout << "No Blank Seats";
}

void EmployeeManager::DeleteAccount(int id)
{
	for (int i = 0; i < 10; i++)
	{
		if (e[i].Getid() == id) {
			e[i].ResetAccount();
			i = 0;
			return;
		}
	}
	cout << "No Matching id Found";
}

void EmployeeManager::UpdateAccount(int id)
{
	for (int i = 0; i < 10; i++)
	{
		if (e[i].Getid() == id) {
			string name;
			string adress;

			cout << "\n\nEnter Name : ";
			cin >> name;
			cout << "Enter Adress of Employee : ";
			cin >> adress;

			e[i].Setname(name);
			e[i].Setadress(adress);
			return;
		}
	}
}

