#include"EmployeeManager.h"
#include"CommonFunctions.h"
#include"FIleHandler.h"


void MenuExpenditure() {
	cout << "----------------CDAC Employee APP------------------------- \n";
	cout << "1. Create Entry                                               \n";
	cout << "2. Delete Entry                                               \n";
	cout << "3. Update Entry                                               \n";
	cout << "Select what you want to do                                     \n\n";
}

Employee CreateEmployee() {
	string Name = getName("Enter the Name of Employee : ");
	int id = getNumber("Enter the Id of Employee : ");
	string adress = getName("Enter the adress of Employee : ");

	Employee e(Name,id,adress);
	return e;
}

bool Process(int option,EmployeeManager* empMgr,string CsvFile) {
	int Id;

	switch (option)
	{
	case 1:
		empMgr->AddAccount(CreateEmployee());
		writeToFile(CsvFile,empMgr);
		return false;
		break;
	case 2:
		Id = getNumber("\nEnter Employee ID Which u want to be Deleted\n");
		empMgr->DeleteAccount(Id);
		writeToFile(CsvFile, empMgr);
		return false;
		break;
	case 3:
		Id = getNumber("\nEnter Employee ID Which u want to be updated\n");
		empMgr->UpdateAccount(Id);
		writeToFile(CsvFile, empMgr);
		return false;
		break;
	default:
		return true;
		break;
	}
}


int main() {
	EmployeeManager* e = new EmployeeManager;
	bool exit;
	int option;
	string CsvFile = "E:\\Assignments\\Assignment 10\\Assignment 10\\Assignment 10\\EmployeeDetails.csv";
	readFromFile(CsvFile,e);

	do
	{
		MenuExpenditure();
		option = getNumber("Select Operation : ");
		exit = Process(option, e,CsvFile);
	} while (exit == false);

	system("Pause");
}