
#include<iostream>
#include<string>
using namespace std;
char* reversestr(char* str)
{
	
	int temp,l,i,j;
	for(l=0;str[l]!='\0';l++);
	for(i=0,j=l-1;i<l/2;i++,j--)
	{
		temp=str[i];
		str[i]=str[j];
		str[j]=temp;
	}
	return str;
}
int main()
{
	char str[50];
	cout<<"Enter the String :";
	cin>>str;
	cout<<"String :"<<str<<endl;
	reversestr(str);
	cout<<"Reverse of string :"<<str;
	
	return 0;
}                                       
