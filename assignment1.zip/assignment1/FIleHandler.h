#pragma once
#include"EmployeeManager.h"
#include<fstream>
#include<sstream>

void writeToFile(string CsvFile,EmployeeManager* empMgr) 
{
	ofstream oFs;
	string value;

	oFs.open(CsvFile,ios::trunc);
	int i = 0;
	
	while(i != 20)
	{
		value = empMgr->GetEmployees(i);
		oFs << value << endl;
		i++;
	}

	oFs.close();
}

void readFromFile(string CsvFile,EmployeeManager* empMgr)
{
	ifstream iFs;
	iFs.open(CsvFile);
	string line = "";
	int index = 0;

	while (iFs)
	{
		getline(iFs, line);
		stringstream s(line);
		string word;
		Employee e;
		int i = 0;

		while (getline(s, word, ',')) {
			if (i == 0)
				e.Setid(stoi(word));
			if (i == 1)
				e.Setname(word);
			if (i == 2)
				e.Setadress(word);
			i++;
		}

		if (index < 20) {
		empMgr->SetEmployees(index, e);
		index++;}
	}
	iFs.close();
}
