#pragma once

#include <string>
#include <iostream>
using  namespace std;

int getNumber(string question) {
	cout << question;
	int no;
	cin >> no;
	return no;
}

string getName(string question) {
	cout << question;
	string no;
	cin.ignore();
	getline(cin,no);
	return no;
}

long int getLargeNumber(string question) {
	cout << question;
	long int no;
	cin >> no;
	return no;
}


