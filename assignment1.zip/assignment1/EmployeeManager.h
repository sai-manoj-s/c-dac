#pragma once
#include "Employee.h"

class EmployeeManager
{
private:
	Employee e[20];

public:
	EmployeeManager();

	void AddAccount(Employee emp);
	void DeleteAccount(int id);
	void UpdateAccount(int id);
	string GetEmployees(int index) 
	{
	 string	value = to_string(e[index].Getid())+ "," + e[index].Getname() + "," + e[index].Getadress();
	 return value;
	}

	void SetEmployees(int index,Employee es) 
	{
		e[index] = es;
	}
};

