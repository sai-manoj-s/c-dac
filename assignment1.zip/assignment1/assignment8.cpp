//assignment 8
//sum and average of one dimensional integer array

#include<iostream>
using namespace std;

int* size;
int input;

int sum(int* array){
	int sum=0;
	
	for(int i =0; i < *size;i++){
		sum += array[i];
	}
	return sum;
}
int avg(int total){
	int avg= total/(*size);
	return avg;
	
}
int* createArray(){
	cout<< "Enter the size of array :\n";
	cin >> input;
	size=&input;
	int* arr= new int[*size];
	
	for(int i=0; i<*size; i++){
		cout << "Enter array Element :\n ";
		cin >> arr[i];
	}
	return arr;

}

int main(){
	int* ar=createArray();
	int total= sum(ar);
	cout <<"Sum of array is : "<< total<< endl;
	cout <<"average of array is :" <<avg(total)<<endl;
}
