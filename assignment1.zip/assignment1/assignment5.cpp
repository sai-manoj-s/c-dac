//assignment 5
//farenheight to centigrate

#include<iostream>
using namespace std;

void convertToCenti(double temp){
	double result;
	result=(temp-32)*5/9;
	cout<< "Temperature in centigrate is : " <<result; 
}


void input(){
	double temperature;
	
	cout <<"enter the temperature in farenheight :\n";
	cin >>temperature;
	convertToCenti(temperature); 
}
int main(){
	input();
	
}
