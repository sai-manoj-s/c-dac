//assignment 2
//print complete message with one cout statement
#include<iostream>


int main(){
	std::cout<<"   Subject\t\tMarks\n  Mathematics\t\t 90\n  Computer\t\t 77\n  Chemistry\t\t 69";
}
