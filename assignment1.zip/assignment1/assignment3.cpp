//assignment3
//print all natural numbers without semicolon
#include<iostream>
#define X 10

int main(int num)
{
 if (num<= X && printf("%d ", num) && main(num + 1))
  {
    }    
}
